
from a3x.fragments.base import BaseFragment

class NoExecuteFragment(BaseFragment):
    pass
