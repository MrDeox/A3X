import pytest
from unittest.mock import patch, MagicMock, mock_open

from a3x.skills.file_system.file_manager import FileManagerSkill

# ... existing code ... 