import pytest
from unittest.mock import patch, mock_open, MagicMock

from a3x.skills.file_system.file_manager import FileManagerSkill, MAX_READ_SIZE

# ... existing code ... 