def skill_weather_forecast(
    entities: dict, original_command: str, intent: str = None, history: list = None
) -> dict:
    """Placeholder para previsão do tempo."""
    return {
        "status": "success",
        "action": "weather_forecast",
        "data": {"message": "Previsão do tempo não implementada ainda."},
    }
