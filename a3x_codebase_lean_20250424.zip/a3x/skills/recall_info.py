def skill_recall_info(
    entities: dict, original_command: str, intent: str = None, history: list = None
) -> dict:
    """Placeholder para recuperação de informação."""
    return {
        "status": "success",
        "action": "recall_info",
        "data": {"message": "Recuperação não implementada ainda."},
    }
