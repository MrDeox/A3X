def skill_search_web(
    entities: dict, original_command: str, intent: str = None, history: list = None
) -> dict:
    """Placeholder para busca web."""
    return {
        "status": "success",
        "action": "search_web",
        "data": {"message": "Busca web não implementada ainda."},
    }
