# Auto-generated __init__.py for A³X skills

# This file makes the auto_generated directory a Python package.
# Import generated skills here to make them discoverable.

# from . import context_example_retrieval # Removed as skill file was deleted
