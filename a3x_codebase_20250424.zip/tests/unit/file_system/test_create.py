import pytest
from unittest.mock import patch, MagicMock
from a3x.skills.file_system.file_manager import FileManagerSkill

# ... existing code ... 