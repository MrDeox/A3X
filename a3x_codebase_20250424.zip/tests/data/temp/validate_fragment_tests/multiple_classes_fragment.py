
from a3x.fragments.base import BaseFragment

class FirstFragment(BaseFragment):
    def execute(self, ctx):
        pass

class SecondFragment(BaseFragment):
    def execute(self, ctx):
        pass
