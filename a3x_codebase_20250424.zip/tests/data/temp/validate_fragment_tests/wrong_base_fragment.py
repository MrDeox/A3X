
class NotAFragment:
    def execute(self, ctx):
        pass
