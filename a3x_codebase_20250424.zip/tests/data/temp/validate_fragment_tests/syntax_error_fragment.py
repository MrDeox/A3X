
from a3x.fragments.base import BaseFragment

class SyntaxErrorFragment(BaseFragment)
    def execute(self, ctx):
        pass
