import asyncio
import logging
import random
import re
import uuid
from typing import Dict, Any, Optional, List, Tuple
from collections import defaultdict
from pathlib import Path # Needed for plan generation target paths

from .base import BaseFragment, FragmentDef
from a3x.core.context import FragmentContext

logger = logging.getLogger(__name__)

# Configuration
PLANNING_TRIGGER_THRESHOLD = 1 # Plan after seeing 1 reflection + 1 summary cycle

# Regex patterns to extract info (adjust if message formats change)
# Corrected Regex Patterns (using raw strings r'...')
SUCCESSFUL_ACTION_PATTERN = re.compile(r"-\s*'(.*?)':\s*(\d+)\s*successes")
FRAGMENT_ERROR_PATTERN = re.compile(r"-\s*'(.*?)':\s*(\d+)\s*errors/failures")
HEURISTIC_PATTERN = re.compile(r"- Count=(\d+): Sender='(.*?)', Action='(.*?)', Target='(.*?)'")

# Where GoalManager creates files (to mimic target generation)
GOAL_TARGET_PREFIX = "a3x/generated/strategic"

class PlannerFragment(BaseFragment):
    """Listens to reflections and learning summaries to plan sequences of actions."""

    def __init__(self, fragment_def: FragmentDef, tool_registry=None):
        super().__init__(fragment_def, tool_registry)
        self._fragment_context: Optional[FragmentContext] = None
        self._reflection_processed = False
        self._summary_processed = False
        # Store extracted insights
        self.recent_successful_actions: Dict[str, int] = {}
        self.recent_erroring_fragments: Dict[str, int] = {}
        self.recent_top_heuristics: List[Tuple[int, str, str, str]] = [] # Changed to tuple
        self._logger.info(f"[{self.get_name()}] Initialized. Will plan after processing reflection and summary.")

    async def get_purpose(self, context: Optional[Dict] = None) -> str:
        """Returns a description of this fragment's purpose."""
        return "Analyzes reflections and learning summaries to generate 'plan_sequence' directives, proposing coordinated actions based on system insights."

    def set_context(self, context: FragmentContext):
        """Receives the context needed to post messages."""
        super().set_context(context.shared_task_context)
        self._fragment_context = context
        self._logger.info(f"[{self.get_name()}] Context received.")

    async def handle_realtime_chat(self, message: Dict[str, Any], context: FragmentContext):
        """Processes incoming reflections and learning summaries."""
        if self._fragment_context is None:
            self.set_context(context)

        msg_type = message.get("type")
        content = message.get("content")

        if msg_type == "REFLECTION" and isinstance(content, dict):
            self._logger.info(f"[{self.get_name()}] Received reflection.")
            reflection_summary = content.get("reflection_summary")
            if reflection_summary:
                self._parse_reflection(reflection_summary)
                self._reflection_processed = True

        elif msg_type == "LEARNING_SUMMARY" and isinstance(content, dict):
            self._logger.info(f"[{self.get_name()}] Received learning summary.")
            summary_text = content.get("summary_text")
            if summary_text:
                 self._parse_summary(summary_text)
                 self._summary_processed = True

        # Check if conditions are met to generate a plan
        if self._reflection_processed and self._summary_processed:
             self._logger.info(f"[{self.get_name()}] Both reflection and summary processed. Attempting to generate plan...")
             await self._generate_plan_sequence()
             # Reset flags after planning
             self._reflection_processed = False
             self._summary_processed = False
             # Clear stored data for next cycle
             self.recent_successful_actions.clear()
             self.recent_erroring_fragments.clear()
             self.recent_top_heuristics.clear()

    def _parse_reflection(self, reflection_text: str):
        """Extracts successful actions and erroring fragments from reflection text."""
        # Extract successful actions
        success_matches = SUCCESSFUL_ACTION_PATTERN.findall(reflection_text)
        for action, count_str in success_matches:
            try:
                self.recent_successful_actions[action] = int(count_str)
            except ValueError: pass
        self._logger.debug(f"[{self.get_name()}] Parsed successful actions: {self.recent_successful_actions}")
        
        # Extract erroring fragments
        error_matches = FRAGMENT_ERROR_PATTERN.findall(reflection_text)
        for fragment, count_str in error_matches:
             try:
                  self.recent_erroring_fragments[fragment] = int(count_str)
             except ValueError: pass
        self._logger.debug(f"[{self.get_name()}] Parsed erroring fragments: {self.recent_erroring_fragments}")

    def _parse_summary(self, summary_text: str):
        """Extracts top heuristics from learning summary text."""
        heuristic_matches = HEURISTIC_PATTERN.findall(summary_text)
        for count_str, sender, action, target_pattern in heuristic_matches:
             try:
                  count = int(count_str)
                  self.recent_top_heuristics.append((count, sender, action, target_pattern))
             except ValueError: pass
        # Keep sorted by count
        self.recent_top_heuristics.sort(key=lambda x: x[0], reverse=True)
        self._logger.debug(f"[{self.get_name()}] Parsed top heuristics: {self.recent_top_heuristics}")

    async def _generate_plan_sequence(self):
        """Generates a plan based on analyzed reflections and heuristics."""
        if not self._fragment_context:
             self._logger.error(f"[{self.get_name()}] Cannot generate plan: Context not set.")
             return

        plan_description = "No specific plan generated based on current insights."
        plan_sequence = [] # List of action descriptions or directives
        plan_source = "Default/NoTrigger"

        # --- Simple Planning Logic Examples --- 

        # 1. If a fragment errors often, try refactoring it based on a successful pattern
        if self.recent_erroring_fragments and self.recent_top_heuristics:
             # Find most error-prone fragment
             most_erroring = max(self.recent_erroring_fragments, key=self.recent_erroring_fragments.get)
             error_count = self.recent_erroring_fragments[most_erroring]
             
             # Find a successful heuristic (simple approach: top one)
             top_heuristic = self.recent_top_heuristics[0]
             h_count, h_sender, h_action, h_target_pattern = top_heuristic

             # Basic plan: try to apply the successful action to the erroring fragment (needs refinement)
             # This is very naive, assumes fragment name can be a target path component
             target_path_guess = f"a3x/fragments/{most_erroring.lower()}.py"
             plan_description = f"Attempt to refactor error-prone fragment '{most_erroring}' ({error_count} errors) using pattern '{h_action}' which succeeded {h_count} times."
             plan_sequence = [
                 {"action": "refactor_module", "target": target_path_guess, "message": f"Refactor {most_erroring} to address recent errors, possibly applying patterns similar to successful '{h_action}' actions."}
             ]
             plan_source = f"ErrorCorrection('{most_erroring}') + Heuristic('{h_action}')"

        # 2. If a creation action is very successful, try creating another one
        elif self.recent_top_heuristics:
            top_heuristic = self.recent_top_heuristics[0]
            h_count, h_sender, h_action, h_target_pattern = top_heuristic
            if h_action == "create_helper_module" and h_count > 5: # Example threshold
                 new_target = f"a3x/generated/planned/helper_{uuid.uuid4().hex[:6]}.py"
                 plan_description = f"Action '{h_action}' by '{h_sender}' is highly successful ({h_count} times). Planning creation of another helper module."
                 plan_sequence = [
                      {"action": "create_helper_module", "target": new_target, "message": f"Create a new helper module at {new_target}, inspired by recent successes."}
                 ]
                 plan_source = f"HeuristicReplication('{h_action}')"

        # TODO: Add more sophisticated planning logic based on combining insights.
        # Example: If 'create' succeeds but then 'refactor' often fails on the same target type -> Plan: create -> test -> maybe suggest different refactor approach.

        # --- Post the Plan --- 
        if plan_sequence:
            self._logger.info(f"[{self.get_name()}] Generated Plan: {plan_description}")
            plan_directive_content = {
                "type": "directive",
                "action": "plan_sequence",
                "target": "system", # Target is the overall system plan
                "message": plan_description,
                "sequence": plan_sequence, # The actual steps
                "source": plan_source
            }
            try:
                await self.post_chat_message(
                    context=self._fragment_context,
                    message_type="architecture_suggestion",
                    content=plan_directive_content
                )
                self._logger.info(f"[{self.get_name()}] Posted 'plan_sequence' directive.")
            except Exception as e:
                self._logger.exception(f"[{self.get_name()}] Failed to post plan_sequence directive:")
        else:
            self._logger.info(f"[{self.get_name()}] No actionable plan generated from current insights.")

    async def shutdown(self):
        """Optional cleanup actions on shutdown."""
        self._logger.info(f"[{self.get_name()}] Shutdown complete.") 