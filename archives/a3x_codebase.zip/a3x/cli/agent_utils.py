# a3x/cli/agent_utils.py
import logging
import uuid
from pathlib import Path
from typing import Optional, Dict, Any

from rich.console import Console

# Import core components needed
try:
    from a3x.core.cerebrumx import CerebrumXAgent
    from a3x.fragments.registry import FragmentRegistry
    from a3x.core.tool_registry import ToolRegistry
    from a3x.core.memory.memory_manager import MemoryManager
    from a3x.core.config import PROJECT_ROOT, MAX_REACT_ITERATIONS
except ImportError as e:
    print(f"[CLI Agent Utils Error] Failed to import core modules: {e}")
    CerebrumXAgent = None
    FragmentRegistry = None
    ToolRegistry = None
    MemoryManager = None
    PROJECT_ROOT = Path(".")
    MAX_REACT_ITERATIONS = 10

logger = logging.getLogger(__name__)
console = Console()

def initialize_agent(
    system_prompt: str,
    llm_url_override: Optional[str] = None,
    loaded_tools: Optional[Dict[str, Any]] = None,
    max_steps: Optional[int] = None
) -> Optional["CerebrumXAgent"]:
    """Initializes the CerebrumX agent instance."""
    if not all([CerebrumXAgent, FragmentRegistry, ToolRegistry, MemoryManager]):
        logger.error("Core agent components (Agent, Registries, Manager) not available due to import error.")
        return None
    
    if loaded_tools is None:
        loaded_tools = {}

    effective_max_steps = max_steps if max_steps is not None else MAX_REACT_ITERATIONS

    try:
        agent_id = f"cli-agent-{uuid.uuid4().hex[:8]}"
        workspace_root = Path(PROJECT_ROOT).resolve()
        
        tool_registry = ToolRegistry()
        if hasattr(tool_registry, 'register_tool_from_dict'):
            for skill_name, skill_info in loaded_tools.items():
                try:
                    pass
                except Exception as reg_err:
                     logger.warning(f"Could not register tool '{skill_name}' from loaded dict: {reg_err}")
            logger.info(f"Populated ToolRegistry with {len(loaded_tools)} skills from loaded_tools dict.")
        else:
             logger.warning("ToolRegistry does not have 'register_tool_from_dict'. Assuming tools are registered elsewhere.")

        fragment_registry = FragmentRegistry()

        memory_config = {
            "SEMANTIC_INDEX_PATH": "a3x/memory/indexes/semantic_memory",
            "DATABASE_PATH": "a3x/memory/memory.db",
        }
        memory_manager = MemoryManager(config=memory_config) 

        agent = CerebrumXAgent(
            agent_id=agent_id,
            system_prompt=system_prompt,
            tool_registry=tool_registry,
            fragment_registry=fragment_registry,
            memory_manager=memory_manager,
            workspace_root=workspace_root,
            llm_url=llm_url_override,
            max_iterations=effective_max_steps
        )
        logger.info(f"Agent initialized successfully (ID: {agent_id}, Max Steps: {effective_max_steps}).")
        return agent
    except Exception as e:
        logger.exception("Failed to initialize agent:")
        console.print(f"[bold red]Error initializing agent:[/bold red] {e}")
        return None 