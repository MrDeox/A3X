def skill_remember_info(
    entities: dict, original_command: str, intent: str = None, history: list = None
) -> dict:
    """Placeholder para memorização de informação."""
    return {
        "status": "success",
        "action": "remember_info",
        "data": {"message": "Memorização não implementada ainda."},
    }
